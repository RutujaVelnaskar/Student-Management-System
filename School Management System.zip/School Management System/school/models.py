from django.db import models

# Create your models here.
class School_data(models.Model):
    school_name = models.CharField(max_length=200)
    def __str__(self):
        return self.school_name


class Student_class(models.Model):
    student_class = models.CharField(max_length=300)
    school = models.ForeignKey(School_data, on_delete=models.CASCADE, related_name="classes")
    def __str__(self):
        return self.student_class


class Teacher(models.Model):
    teacher_name = models.CharField(max_length=300)
    school = models.ForeignKey(School_data,on_delete=models.CASCADE,related_name="teachers")
    student_class = models.OneToOneField(Student_class, on_delete=models.CASCADE,related_name="teacher")
    def __str__(self):
        return self.teacher_name


class Student(models.Model):
    student_name = models.CharField(max_length=200)
    roll_no = models.IntegerField()
    school = models.ForeignKey(School_data, on_delete=models.CASCADE, related_name="students")
    student_class = models.ForeignKey(Student_class, on_delete=models.CASCADE, related_name="students")
    def __str__(self):
        return self.student_name

