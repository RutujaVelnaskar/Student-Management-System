from django.shortcuts import render, redirect
from .models import School_data,Student_class,Teacher,Student

# Create your views here.

def indexpage(request):
    return render(request, "index.html")



def school_name(request):
    school = School_data.objects.first()
    if request.method == "POST":
        action = request.POST.get("action")
        if action == "save":
            sname = request.POST.get("sname")
            if sname:
                if school:
                    school.school_name = sname
                    school.save()
                else:
                    School_data.objects.create(school_name=sname)
            return redirect("school_name")
        elif action == "delete":
            if school:
                school.delete()
            return redirect("school_name")
    return render(request, "school.html",{"school": school})

def student_class(request):
    school = School_data.objects.first()
    student_classes = Student_class.objects.filter(school=school)
    if request.method == "POST":
        action = request.POST.get("action")
        if action == "save":
            class_name = request.POST.get("student_class")
            if school and class_name:
                class_exists = Student_class.objects.filter(school=school, student_class=class_name).exists()
                if not class_exists:
                    Student_class.objects.create(student_class=class_name, school=school)
            return redirect("student_class")
        elif action == "delete":
            class_id = request.POST.get("class_id")
            if class_id and school:
                Student_class.objects.filter(id=class_id, school=school).delete()
            return redirect("student_class")
    return render(request, "student_class.html",{"school": school, "student_classes": student_classes})

def teacher(request):
    school = School_data.objects.first()
    student_classes = Student_class.objects.filter(school=school)
    teachers = Teacher.objects.filter(school=school).select_related("student_class")
    if request.method == "POST":
        action = request.POST.get("action")
        if action == "save":
            teacher_name = request.POST.get("teacher_name")
            class_id = request.POST.get("student_class")
            if not school:
                return render(request,"teacher.html",
                    {
                        "school": school,
                        "student_classes": student_classes,
                        "teachers": teachers,
                        "error": "First create a school."
                    }
                )

            if not teacher_name:
                return render(request,"teacher.html",
                    {
                        "school": school,
                        "student_classes": student_classes,
                        "teachers": teachers,
                        "error": "Teacher name is required."
                    }
                )

           
            if not class_id:
                return render(
                    request,
                    "teacher.html",
                    {
                        "school": school,
                        "student_classes": student_classes,
                        "teachers": teachers,
                        "error": "Please select a class."
                    }
                )

          
            try:
                selected_class = Student_class.objects.get(id=class_id,school=school)
            except Student_class.DoesNotExist:
                return render(request, "teacher.html",
                    {
                        "school": school,
                        "student_classes": student_classes,
                        "teachers": teachers,
                        "error": "Invalid class selected."
                    }
                )

            if Teacher.objects.filter(student_class=selected_class).exists():
                return render(request,"teacher.html",
                    {
                        "school": school,
                        "student_classes": student_classes,
                        "teachers": teachers,
                        "error": "This class already has a teacher."
                    }
                )

           
            Teacher.objects.create(teacher_name=teacher_name,school=school,student_class=selected_class)
            return redirect("teacher")

        elif action == "delete":
            teacher_id = request.POST.get("teacher_id")
            if teacher_id and school:
                Teacher.objects.filter(id=teacher_id, school=school).delete()
            return redirect("teacher")
    return render(request,"teacher.html",
        {
            "school": school,
            "student_classes": student_classes,
            "teachers": teachers
        }
    )


def student(request):
    school = School_data.objects.first()
    student_classes = Student_class.objects.filter(school=school)
    students = Student.objects.filter(school=school).select_related("school","student_class")
    if request.method == "POST":
        action = request.POST.get("action")
        if action == "save":
            student_name = request.POST.get("student_name")
            roll_no = request.POST.get("roll_no")
            class_id = request.POST.get("student_class")

            if not school:
                return render(request, "student.html",
                    {
                        "school": school,
                        "student_classes": student_classes,
                        "students": students,
                        "error": "First create a school."
                    }
                )

           
            if not student_name:
                return render(request,"student.html",
                    {
                        "school": school,
                        "student_classes": student_classes,
                        "students": students,
                        "error": "Student name is required."
                    }
                )

          
            if not roll_no:
                return render(request,"student.html",
                    {
                        "school": school,
                        "student_classes": student_classes,
                        "students": students,
                        "error": "Roll number is required."
                    }
                )

            if not class_id:
                return render(request, "student.html",
                    {
                        "school": school,
                        "student_classes": student_classes,
                        "students": students,
                        "error": "Please select a class."
                    }
                )

            try:
                selected_class = Student_class.objects.get(id=class_id, school=school)
            except Student_class.DoesNotExist:
                return render(request,"student.html",
                    {
                        "school": school,
                        "student_classes": student_classes,
                        "students": students,
                        "error": "Invalid class selected."
                    }
                )

            roll_exists = Student.objects.filter(school=school,student_class=selected_class,roll_no=roll_no).exists()
            if roll_exists:
                return render(request,"student.html",
                    {
                        "school": school,
                        "student_classes": student_classes,
                        "students": students,
                        "error": "This roll number already exists in this class."
                    }
                )

            Student.objects.create(
                student_name=student_name,
                roll_no=roll_no,
                school=school,
                student_class=selected_class
            )
            return redirect("student")
        
        elif action == "delete":
            student_id = request.POST.get("student_id")
            if student_id and school:
                Student.objects.filter(id=student_id,school=school).delete()
            return redirect("student")
    return render(request,"student.html",
        {
            "school": school,
            "student_classes": student_classes,
            "students": students
        }
    )

def teacher_students(request, teacher_id):
    school = School_data.objects.first()
    try:
        teacher_data = Teacher.objects.get(id=teacher_id, school=school)
    except Teacher.DoesNotExist:
        return redirect("teacher")
    students = Student.objects.filter(school=school, student_class=teacher_data.student_class).order_by("roll_no")
    return render(request,"teacher_students.html",{"teacher": teacher_data,"students": students})


